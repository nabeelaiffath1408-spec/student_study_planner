# Student Study Planner – SAS Model

A beginner-friendly Flask web project for organizing study tasks and tracking academic progress using the Smart Academic Scheduling (SAS) concept.

## Features
- Add tasks with a subject and due date
- Mark tasks as completed or active
- Delete tasks
- Dashboard counters and completion percentage
- Responsive layout for desktop and mobile

## Tech stack
- Python
- Flask
- HTML and CSS

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this project folder.
3. Create and activate a virtual environment (recommended).
4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Start the app:

   ```bash
   python app.py
   ```

6. Visit http://127.0.0.1:5000 in your browser.

## Note
This is a learning/demo version. Tasks are stored in memory, so they reset when the server restarts. A database such as SQLite can be added as a future enhancement.
