from flask import Flask, render_template, request, redirect, url_for
from datetime import date

app = Flask(__name__)

# Demo data is kept in memory. Restarting the app resets it.
subjects = ["Mathematics", "Science", "English"]
tasks = [
    {"id": 1, "title": "Revise algebra", "subject": "Mathematics", "due": "2026-11-05", "done": False},
    {"id": 2, "title": "Read chapter 3", "subject": "Science", "due": "2026-11-06", "done": False},
]
next_id = 3

@app.route("/")
def index():
    total = len(tasks)
    completed = sum(task["done"] for task in tasks)
    return render_template("index.html", tasks=tasks, subjects=subjects,
                           total=total, completed=completed, today=date.today().isoformat())

@app.route("/add", methods=["POST"])
def add_task():
    global next_id
    title = request.form.get("title", "").strip()
    subject = request.form.get("subject", "").strip()
    due = request.form.get("due", "").strip()
    if title and subject and due:
        tasks.append({"id": next_id, "title": title, "subject": subject, "due": due, "done": False})
        next_id += 1
    return redirect(url_for("index"))

@app.route("/toggle/<int:task_id>", methods=["POST"])
def toggle_task(task_id):
    for task in tasks:
        if task["id"] == task_id:
            task["done"] = not task["done"]
            break
    return redirect(url_for("index"))

@app.route("/delete/<int:task_id>", methods=["POST"])
def delete_task(task_id):
    tasks[:] = [task for task in tasks if task["id"] != task_id]
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
